# CHECKPOINT 002 — Guarded Fog Hook

## State
Implemented source prototype. Core Java self-test passes. Full Fabric/Loom compilation is still a release gate because Gradle/Fabric dependencies are not available offline in the execution environment.

## Render contract
- One Mixin only: BackgroundRenderer.applyFog.
- ModifyArgs targets the Fog constructor Minecraft already executes.
- No framebuffer, post-process, second world render or shader injection.
- No biome/config/network/registry/mod-loader reads in the render hook.
- One reusable MutableAtmosphereFrame.
- Underwater/lava/powder-snow, blindness/darkness and vanilla thick fog remain vanilla.
- Circuit breaker: unexpected hook failure disables only atmosphere fog and falls back to vanilla.
- Emergency JVM switch: -Dlyrius.atmosphere.disableFog=true.

## Visual baseline
Fallback presets were expanded with restrained medieval/low-fantasy profiles for dark forest, old-growth taiga, swamp, mountains and arid biomes. Transitions are 1.8–2.6 seconds smoothstep.

## Not yet enabled
- Shader-specific handling.
- Distant Horizons adapter.
- Server-sent configuration.
- Sky/horizon hooks.
