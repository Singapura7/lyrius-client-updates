# CHECKPOINT 005 — Visual Variant Library

## Objective
Add medieval / low / mid / high fantasy variation by biome + day band + weather without adding work to the render path.

## Runtime model
- Biome selection stays O(1) map lookup and occurs only on context change.
- Day/weather variant selection is a fixed 12-slot array: weather ordinal × day ordinal.
- No string building, map iteration or parsing in ProfileResolver.
- TransitionState uses primitive anchors and performs no AtmosphereProfile allocation when retargeting.
- Once a transition finishes, smoothstep/lerp stops until another target change.
- Biome sampling is tied to 4×4×4 quart-cell changes; no repeated getBiome while staying in the same quart cell.

## Art direction baseline
LOW: natural medieval readability, broad visibility, restrained earthy/cool palette.
MID: denser local mood for old forests/swamps; still gameplay-readable.
HIGH: supernatural dimension profiles for Nether/End; stronger color identity but same rendering cost.

## Weather/time behavior
Dawn and dusk are subtle tint/density changes. Night is cooler and slightly denser. Rain lowers the horizon and desaturates. Thunder is the densest variant. Every change becomes a new cached target and transitions over ~2–3 seconds.

## Important persistence note
CP003/CP004 documents exist in Drive, but their source archives were not found in the expected project folders at the start of this checkpoint. CP005 is therefore preserved as an isolated visual/core source line and must be merged with the recovered/reconstructed platform-sync line before release.
