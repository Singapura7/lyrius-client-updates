# Render Hot Path Budget

Per eligible vanilla terrain fog pass:
1. booleans / enum checks;
2. cached runtime pointer;
3. System.nanoTime;
4. TransitionState smoothstep interpolation over primitive floats;
5. clamp to current view distance;
6. mutate seven constructor args.

Explicitly forbidden on this path:
- world.getBiome
- registry queries
- JSON/YAML parsing
- disk/network I/O
- FabricLoader scans
- reflection
- streams/collections iteration
- framebuffer creation
- extra world draw
- logging except one-time circuit breaker failure
