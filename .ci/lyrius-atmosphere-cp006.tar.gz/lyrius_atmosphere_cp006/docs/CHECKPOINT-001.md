# CHECKPOINT 001 — Runtime/cache skeleton

Status: SOURCE SKELETON + CORE SELF-TEST PASSED. Full Fabric game boot still requires dependency resolution/build in a Fabric-capable environment.

## What is frozen

- Minecraft 1.21.4, Java 21, Fabric Loader >=0.16.10.
- No render hooks or mixins in CP001.
- Active configuration is an immutable `AtmosphereSnapshot` behind an `AtomicReference`.
- Snapshot resolution is O(1) over precompiled maps.
- Configuration is never parsed/read on the render path.
- Mod detection occurs once during startup.
- Context changes are emitted only when dimension/biome/weather/day band actually changes.
- Biome probing is capped at 10 Hz and only after movement/world change.
- Weather/day-band probing is capped at 2 Hz.
- Renderer-facing interpolation is allocation-free via one reusable `MutableAtmosphereFrame`.
- No custom framebuffer, no second world render, no post-process pass.

## Why the biome sampler is not frame-bound

Minecraft may render at 60–240+ FPS, while game/client ticks run at 20 TPS. Atmospheric profile selection does not need frame frequency. CP001 therefore samples context on the client tick lane, with additional throttling, and emits a new context only when it is observably different.

This means the future CP002 render hook will do only:

1. read the current transition state;
2. interpolate primitive floats;
3. apply those values to vanilla fog.

It will not query biome registries, parse JSON, scan rule lists, touch disk, poll the server, or rescan installed mods.

## Deliberate trade-off

Biome lookup is capped at 10 Hz rather than tied strictly to 4x4x4 biome storage cells. `WorldView#getBiome(BlockPos)` reflects Minecraft's actual biome-access behavior at the player's position, which is preferable near biome boundaries. Ten cached client-world lookups/second while moving are negligible compared with frame rendering and avoid visual misclassification at borders.

## CP002 gate

Do not add fog mixins until the Fabric project is built and smoke-tested with the Lyrius client stack. When CP002 starts, use one narrow optional mixin around Minecraft 1.21.4 `BackgroundRenderer.applyFog` / `getFogColor`, preserving vanilla status-effect/water/lava semantics and degrading to vanilla if Iris/shader ownership makes the result unsafe.
