# Optimization review — CP001

## Hot-path budget

### Every frame (future CP002)
Allowed:
- `System.nanoTime()` or render clock already supplied by MC;
- a few float lerps/smoothstep operations;
- reading already-resolved primitive state;
- applying parameters to vanilla fog.

Forbidden:
- biome lookup;
- registry lookup;
- JSON/Gson parsing;
- file I/O;
- network I/O;
- reflection/class discovery;
- collection iteration;
- map rule resolution;
- logging;
- new lists/maps/strings.

### Every client tick (20 Hz)
Allowed:
- world/player null check;
- integer position comparison;
- counters/dirty flags.

### At most 10 Hz while moving
- one `world.getBiome(mutableBlockPos)`;
- convert biome registry key to stable id only when sampled.

### At most 2 Hz
- weather band;
- coarse day band.

### Rare events only
- snapshot parse/validation/compile;
- server config sync;
- mod compatibility discovery;
- reload/resync diagnostics.

## Stability policy

The visual engine must not own world state. It observes client state and modifies only fog/sky presentation. Failure of an optional visual hook must result in vanilla output, not a crash or corrupted world/session.
