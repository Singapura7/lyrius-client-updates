# CHECKPOINT 006 — Consolidação Sync + Variantes

Status: IMPLEMENTADO EM SOURCE / TESTES LOCAIS PASS / BUILD REAL E BOOT AINDA PENDENTES.

- Reconstructed CP003/CP004 protocol and platform adapters into the CP005 source tree.
- Schema v2 transports fixed 4 day bands x 3 weather bands without JSON/YAML on the client.
- Canonical deterministic encoding + SHA-256 + bounded GZIP + 24 KiB chunks.
- Client cache is keyed per server and accepted only after hash validation and successful snapshot decode.
- Paper reload is transactional and preserves the last valid revision on parse/validation failure.
- Server compresses/hash/chunks once per revision and reuses the plan for all players.
- Global server transfer budget: 32 chunks/tick round-robin.
- Client worker queue is bounded; timeout triggers a resync rather than growing memory.
- Old-revision chunks are ignored/cancelled.
- Renderer remains isolated from sync, disk and config work.

Tests: AtmosphereCoreSelfTest PASS; AtmosphereVariantSelfTest PASS; SnapshotBinaryCodecSelfTest PASS; ProtocolSelfTest PASS; EndToEndSyncSelfTest PASS; full client source stub compile PASS; Paper source stub compile PASS; config.yml YAML parse PASS.
